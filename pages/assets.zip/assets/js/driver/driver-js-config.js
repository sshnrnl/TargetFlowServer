const driverObj = window.driver.js.driver({
    allowClose:false
  });
//   driverObj.highlight({
//     element: '#dates',
//     popover:{
//         title: '',
//         description:'Pilih waktu untuk memulai'
//     },
    
//   });

$('#dates').on('click', function(){

    
    // driverObj.destroy()
    // driverObj.highlight({
    //     element: '.datepicker-dates.is-active',
    //     popover:{
    //         title: '',
    //         description:'Pilih tanggal awal',
    //         side:'top',
    //         align:'center'
    //         // popoverClass:'popmb'
    //     },
        
    // });

})
