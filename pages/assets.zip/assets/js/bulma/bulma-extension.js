$('.datetimepicker-header').empty()
$( ".datetimepicker-header" ).append( `
<div style="display: flex;width: 100%;justify-content: center;">
    <div id="start" class="buttonStartEnd active">Start</div>
    <div id="end" class="buttonStartEnd">End</div>
</div>` );

// $('.buttonStartEnd').on('click',function(){
//     var array_li = new Array();

//     $('.datepicker-date.datepicker-range-start').each(function() {
//         array_li.push(1);
//     });
//     if(array_li.length){
//         $('.buttonStartEnd').removeClass('active')
//         $(this).addClass('active')
//         checkDate()
//         if($('#start').hasClass('active')){
//             $('.timepicker-start').css('display','flex')
//             $('.timepicker-end').css('display','none')
//             $('.datetimepicker-footer').attr('style', 'display: none !important')
//             $('.is-kindaDisabled').removeClass('is-kindaDisabled')
//         }
//         else{
//             setTimeout(function(){
//                 driverObj.destroy();
//                 // driverObj.destroy()
//                 driverObj.highlight({
//                     element: '.datepicker-dates.is-active',
//                     popover:{
//                         title: '',
//                         description:'Pilih tanggal akhir',
//                         // popoverClass:'popmb'
//                     },
                    
//                 });
//             },100)
//             $('.is-kindaActive>button').prop('disabled',false)
            
//             $('.timepicker-start').css('display','none')
//             $('.timepicker-end').attr('style','display: flex !important');
//             $('.datepicker-date').each(function(){
//                 if($(".date-item",this).hasClass('is-active')){return false}
//                 $(this).not('.is-disabled').addClass('is-kindaDisabled')
//             })
//             $('.datetimepicker-footer').attr('style', 'display: flex !important')
//         }
//     }
    


// })

// $('.date-item').on('click',function(){console.log('asf')})

// setInterval(function(){$('.date-item').on('click',function(){
//     // console.log('asdf')
//     // $("a").trigger("click");

//     setTimeout(
//         function(){
//             // $("#end").trigger("click");
            
        

//     },1)
    
// })}, 1);



// $('.buttonStartEnd').removeClass('active')
//     // console.lof('asdf')
//     $(this).addClass('active')