// config


function init(){
    $('.datetimepicker-footer').clone().attr("id","progressController").appendTo('.datetimepicker')
    $('#progressController').attr('style', 'display: flex !important').appendTo('.datetimepicker')
    $('#progressController>button:first-child').clone().attr('style', 'display: none !important').attr("onclick","frontSequence()").appendTo('#progressController').html("Next")
    $('#progressController>button:first-child').attr('style', 'display: none !important')
    $('#progressController>button:nth-child(4)').attr('onclick', 'backSequence()')
    $("#dates").click()
    sequence0()

}

function endSequence(){
    sequence=0;
    myCal[0].onValidateClickDateTimePicker(myCal[0])
    $(".modal-background, .datetimepicker").css('display','none');
              $(`#list-barang`).animate({height: 'hide',opacity:'hide'},1500,'easeInOutQuint');
              changeDate($('.demo').val())
              
              setTimeout(function() {
                postDate($('.demo').val())
              }, 1);
              driverObj.destroy();
}

init()

// switch(sequence){
//     case 0:sequence0();break
//     case 1:sequence1();break
// }
function checkSequence(){
    switch(sequence){
        case 0:sequence0();break
        case 1:sequence1();break
        case 2:sequence2();break
        case 3:sequence3();break
    }
}

function backSequence(){
    if(sequence>0){
    sequence-=1}
    checkSequence()

}
function frontSequence(){
    if(sequence<4){
    sequence+=1}
    checkSequence()

}

function enableNext(){
    $('#progressController>button:last-child').attr('style', 'display: block !important')

}

function disableNext(){
    $('#progressController>button:last-child').attr('style', 'display: none !important')

}


function sequence0(){
    $('#progressController>button:last-child').attr('onclick', 'frontSequence()').html("Next")

    $('.is-kindaDisabled').removeClass('is-kindaDisabled')
    $('.buttonStartEnd').removeClass('active')
    $('#start').addClass('active')
    $(".timepicker").css('display','none');
    $(".datepicker-body").css('display','flex');
    $(".datepicker-nav-previous").prop('disabled',false)


    

    
    // .attr('style', 'display: flex !important')
    // $(".timepicker").css('display','none');

    driverObj.destroy()
    driverObj.highlight({
        element: '.datetimepicker',
        popover:{
            title: '',
            description:'Pilih tanggal awal',
            side:'top',
            align:'center'
            // popoverClass:'popmb'
        },
        
    });
}

function sequence1(){
    $('#progressController>button:last-child').attr('onclick', 'frontSequence()').html("Next")


    $('.is-kindaDisabled').removeClass('is-kindaDisabled')
    $('.buttonStartEnd').removeClass('active')
    $('#start').addClass('active')
    $(".datepicker-body").css('display','none');
    $(".datepicker-nav-previous").prop('disabled','disabled')
    $(".datepicker-nav-next").prop('disabled','disabled')
    $(".timepicker-start").css('display','flex');
    $(".timepicker-end").prop('style','display:none!important');



    $(".timepicker").css('display','flex');

    driverObj.destroy()
          driverObj.highlight({
            element: '.datetimepicker',
              
              popover:{
                //   popoverClass: "popmb",
                  title: '',
                  description:'Pilih jam awal',
                  side: "top",
                  align: 'center',
                  
              },
              // showButtons:['close']
              
          });
}
function sequence2(){
    disableNext()
    var array_li = new Array();

        $('.datepicker-date.datepicker-range-end, .datepicker-date.datepicker-range-start').each(function() {
          array_li.push(1);
        });
        if(array_li.length==2){enableNext()}
    $('#progressController>button:last-child').attr('onclick', 'frontSequence()').html("Next")

    
    $('.buttonStartEnd').removeClass('active')
    $('#end').addClass('active')

    $(".datepicker-body").css('display','flex');
    $(".datepicker-nav-previous").prop('disabled','disabled')
    $(".datepicker-nav-next").prop('disabled',false)


    $(".timepicker").css('display','none');

    driverObj.destroy()
          driverObj.highlight({
            element: '.datetimepicker',
              
              popover:{
                //   popoverClass: "popmb",
                  title: '',
                  description:'Pilih tanggal akhir',
                  side: "top",
                  align: 'center',
                  
              },
              // showButtons:['close']
              
          });
          $('.datepicker-days>.datepicker-date').each(function(){
            if($(".date-item",this).hasClass('is-active')){return false}
            $(this).not('.is-disabled').addClass('is-kindaDisabled')
        })
}

function sequence3(){
    $('.is-kindaDisabled').removeClass('is-kindaDisabled')
    $(".datepicker-body").css('display','none');
    $(".datepicker-nav-previous").prop('disabled','disabled')
    $(".datepicker-nav-next").prop('disabled','disabled')


    $(".timepicker").css('display','flex');
    $(".timepicker-start").css('display','none');
    $(".timepicker-end").prop('style','display:flex!important');
    $('#progressController>button:last-child').html('Submit').attr('onclick', 'endSequence()')


    driverObj.destroy()
          driverObj.highlight({
            element: '.datetimepicker',
              
              popover:{
                //   popoverClass: "popmb",
                  title: '',
                  description:'Pilih jam akhir',
                  side: "top",
                  align: 'center',
                  
              },
              // showButtons:['close']
              
          });
    
}