function changeDate(dates){
    var datesJson={
        "1":"Jan",
        "2":"Feb",
        "3":"Mar",
        "4":"Apr",
        "5":"Mei",
        "6":"Juni",
        "7":"Juli",
        "8":"Agu",
        "9":"Sep",
        "10":"Okt",
        "11":"Nov",
        "12":"Dec",
    }
    a=dates.split('-')
    a[1]=datesJson[a[1]]
    a[2]=a[2]+" -"
    a[4]=datesJson[a[4]]
    $("#date-range").html(a.join(" ")).css('display','block')
}





function postDate(dates){
    a=dates.split('-')
    // console.log()
    var packagesent={'start': a.slice(0,3).join("-"),'end': a.slice(3,6).join("-")}
    $.ajax({
        url: 'https://technoplastika.my.id/api/v2/get-production',
        type: 'POST',
        data: JSON.stringify(packagesent),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        traditional: true,
        success:function(response){
            $("#list-barang>div").not(".list-template").remove()
            for(var i =0;i<response['items'].length;i++){
                $(".list-template:first-child").clone().appendTo('#list-barang')
                $(".list-template>div>h5").last().html(response['items'][i]['item'])
                $(".list-template>div>#card-hour").last().contents().get(0).nodeValue=response['items'][i]['avg']+" / Jam "
                $(".list-template>div>#card-total").last().contents().get(0).nodeValue="Total: "+response['items'][i]['qty']+" Dus"
                $(".list-template>div>#card-hour>span").last().contents().get(0).nodeValue="• "+$("#date-range").html()+` (${response['time']} Jam)`
            }
            $('.list-template').not('.list-template:first-child').removeClass('list-template')
            $(`#list-barang`).animate({height: 'show',opacity:'show'},1500,'easeInOutQuint');
        },
        error:function(error){
        }
  
      
        
        
      });
}