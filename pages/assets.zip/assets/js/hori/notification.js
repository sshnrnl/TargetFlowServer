notis = new Notifications(document.querySelector(".notifications"))

const demonotis = [
  () => {notis.create("", "Pilih tanggal start", 5)},
  () => {notis.create("", "Atur waktu start berupa jam & menit", 5)},
  () => {notis.create("", 'Klik tombol "End" di atas jika sudah mengatur waktu', 5)},
  () => {notis.create("Customisation", "you can even customise the duration and add actions on click", 10)},
  () => {notis.create("Click me", "try clicking this for a surprise!", 5, true, () => notis.create("Surprise", "Wow, you clicked the previous notification,", 4))},
  () => {notis.create("Animations", "all the animations stay smooth even when notifications disappear out of order or when multiple appear at once", 15)},
]
// let i = 1;
// demonotis[0]()
// setInterval(()=>{
//   if (i == demonotis.length) {
//     notis.create("Demo done", "click on this notification to restart the demo or go look at the code if you're interested", 0, true, () => {i = 0})
//   } else if (i < demonotis.length) {
//     demonotis[i]()
//   }
//   i++
// }, 4000)