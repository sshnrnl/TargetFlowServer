

jQuery(function(){
  $('#kodefield').on('focus', function() {
    before = $(this).html();
    
    }).on('blur keyup paste', function() { 
    if (before != $(this).html()) { $(this).trigger('change'); }
    });
  
  $("#kodefield").keypress(function(e){ if(e.which==13)$(this).blur();return e.which != 13; });

  $('#kodefield').on('blur', function() {
    
    $.ajax({
      url: 'https://technoplastika.my.id/api/v2/nama-product',
      type: 'POST',
      data: JSON.stringify({'data': $(this).val()}),
      contentType: "application/json; charset=utf-8",
      dataType: "json",
      traditional: true,
      success:function(response){
        // $('.card-body').css("display","block");
        $(`.card-body`).animate({opacity: 'show', height: 'show',marginTop:'show',paddingTop:'show'},1500,'easeOutQuint');
        $('#nr').text(response['nr'])
        // $('#customer').text(response['customer'])
        $('#customer').html(`${response['customer']}<span id="tanggal" class="font-1rem" style="color: #f3f3f3;font-weight: 300;font-size: 1.25rem;"> • ${response['tgl']}</span>`);
        // $("#tanggal").text(response['tgl']);
      },
	  error:function(error){
		// $('.card-body').css("display","none");
    $(`.card-body`).animate({opacity: 'hide', height: 'hide',marginTop:'hide',paddingTop:'hide'},1500,'easeInQuint');

	  }

    
	  
      
    });
  });

  
  
});

function ellipsAnimate(){
  if($(`#ellips-container`).css('display')=='none'){
    $(`section`).animate({opacity: 'hide'},1000,'easeOutQuint');

    $(`#ellips-container`).animate({opacity: 'show', height: 'show',marginTop:'show'},1500,'easeOutQuint');
  }
  else{
    $(`#ellips-container`).animate({opacity: 'hide', height: 'hide',marginTop:'hide'},1500,'easeOutQuint');
    $(`section`).animate({opacity: 'show'},1000,'easeOutQuint');

  }
}

function font(num){
  $('.font-3-5rem').css('font-size',(num/100*3.5).toString()+"rem")
  $('.font-3rem').css('font-size',(num/100*3).toString()+"rem")
  $('.font-2-5rem').css('font-size',(num/100*2.5).toString()+"rem")
  $('.font-2rem').css('font-size',(num/100*2).toString()+"rem")
  $('.font-1-75rem').css('font-size',(num/100*1.75).toString()+"rem")
  $('.font-1-5rem').css('font-size',(num/100*1.5).toString()+"rem")
  $('.font-1-25rem').css('font-size',(num/100*1.25).toString()+"rem")
}


