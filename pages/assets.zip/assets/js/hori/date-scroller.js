let lastscrollp = 0;
let lasttouchp = 0;

$('.timepicker-input').on("touchstart", (e) => {
	lasttouchp = e.changedTouches[0].pageY;
	console.log(lasttouchp)
});

$('.timepicker-start>.timepicker-hours>.timepicker-input').on("touchmove", (e) => {
	e.preventDefault();
	console.log("touch " + e.changedTouches[0].pageY);
	let diff = e.changedTouches[0].pageY - lasttouchp;
	let updown = 0;
	if (diff > 30) {
		updown = -1;
		lasttouchp = e.changedTouches[0].pageY;
	} else {
		if (diff < -30) {
			updown = 1;
			lasttouchp = e.changedTouches[0].pageY;
		}
	}
	if(updown>0){
		window.navigator.vibrate(8);
		myCal[0].timePicker.onNextHourStartTimePicker(myCal[0])
		}
	else if(updown<0){
		window.navigator.vibrate(8);
		myCal[0].timePicker.onPreviousHourStartTimePicker(myCal[0])
		}
});

$('.timepicker-start>.timepicker-minutes>.timepicker-input').on("touchmove", (e) => {
	e.preventDefault();
	console.log("touch " + e.changedTouches[0].pageY);
	let diff = e.changedTouches[0].pageY - lasttouchp;
	let updown = 0;
	if (diff > 10) {
		updown = -1;
		lasttouchp = e.changedTouches[0].pageY;
	} else {
		if (diff < -10) {
			updown = 1;
			lasttouchp = e.changedTouches[0].pageY;
		}
	}
	if(updown>0){
		window.navigator.vibrate(8);
		myCal[0].timePicker.onNextMinuteStartTimePicker(myCal[0])
		}
	else if(updown<0){
		window.navigator.vibrate(8);
		myCal[0].timePicker.onPreviousMinuteStartTimePicker(myCal[0])
		}
});

$('.timepicker-end>.timepicker-hours>.timepicker-input').on("touchmove", (e) => {
	e.preventDefault();
	console.log("touch " + e.changedTouches[0].pageY);
	let diff = e.changedTouches[0].pageY - lasttouchp;
	let updown = 0;
	if (diff > 30) {
		updown = -1;
		lasttouchp = e.changedTouches[0].pageY;
	} else {
		if (diff < -30) {
			updown = 1;
			lasttouchp = e.changedTouches[0].pageY;
		}
	}
	if(updown>0){
		window.navigator.vibrate(8);
		myCal[0].timePicker.onNextHourEndTimePicker(myCal[0])
		}
	else if(updown<0){
		window.navigator.vibrate(8);
		myCal[0].timePicker.onPreviousHourEndTimePicker(myCal[0])
		}
});

$('.timepicker-end>.timepicker-minutes>.timepicker-input').on("touchmove", (e) => {
	e.preventDefault();
	console.log("touch " + e.changedTouches[0].pageY);
	let diff = e.changedTouches[0].pageY - lasttouchp;
	let updown = 0;
	if (diff > 10) {
		updown = -1;
		lasttouchp = e.changedTouches[0].pageY;
	} else {
		if (diff < -10) {
			updown = 1;
			lasttouchp = e.changedTouches[0].pageY;
		}
	}
	if(updown>0){
		window.navigator.vibrate(8);
		myCal[0].timePicker.onNextMinuteEndTimePicker(myCal[0])
		}
	else if(updown<0){
		window.navigator.vibrate(8);
		myCal[0].timePicker.onPreviousMinuteEndTimePicker(myCal[0])
		}
});

// $('.timepicker-start>.timepicker-hours').on('mousedown touchstart', function(e) {
//     $(this).data('p0', { x: e.pageX, y: e.pageY });
//     e.stopPropagation();
//     var epy=e.pageY
//     if(!epy)epy=e.touches[0].pageY;

//     var current=0;
//     function foo() {

//         $(window).on("mousemove touchmove",(y)=>{
//             y.stopPropagation();
//             yValue=y.clientY
//             if(!yValue)yValue=y.touches[0].clientY;
//             var temp=parseInt((epy-parseInt(yValue))/50)
//             console.log(parseInt(yValue))
            

//         if(current!=temp)
//         {
//             if(current<temp){window.requestAnimationFrame(myCal[0].timePicker.onNextHourStartTimePicker)}
//             if(current>temp){window.requestAnimationFrame(myCal[0].timePicker.onPreviousHourStartTimePicker)}
            
//             // else if(current<temp){
//             // $(document).on("mousemove",myCal[0].timePicker.onPreviousHourStartTimePicker)
//             // setTimeout(() => {
//             //     $(document).off()
//             // }, 10);}
            

//             current=temp
//         }
        
        
//     })

    
//     }

//     foo();
//     e.preventDefault();
// })
